
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;

@WebServlet(urlPatterns = {"/Mail"})
public class Mail extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    public String passwordGenerator() {
        String letters = "AbcdEFGhijkLmnOpqrStUVwxYz";
        String numbers = "01234567891";
        String combination = letters + numbers;
        Random random = new Random();
        String pswd = "";
        char[] password = new char[10];
        password[0] = combination.charAt(random.nextInt(combination.length()));
        password[1] = combination.charAt(random.nextInt(combination.length()));
        password[2] = combination.charAt(random.nextInt(combination.length()));
        password[3] = combination.charAt(random.nextInt(combination.length()));
        password[4] = combination.charAt(random.nextInt(combination.length()));
        password[5] = combination.charAt(random.nextInt(combination.length()));
        password[6] = combination.charAt(random.nextInt(combination.length()));
        password[7] = combination.charAt(random.nextInt(combination.length()));
        password[8] = combination.charAt(random.nextInt(combination.length()));

        for (int i = 0; i < password.length; i++) {
            pswd += password[i];
        }
        return pswd;

    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            ResultSet rs = null;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            String user_name = request.getParameter("username");
            String name = request.getParameter("name");
            String phoneNumber = request.getParameter("phone_number");
            String email = request.getParameter("email");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Mail</title>");
            out.println("</head>");
            out.println("<body>");

           
            final String username = "universitysystem0@gmail.com";
            final String Password = "university_system";

            Properties props = new Properties();
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");

            Session session = Session.getInstance(props,
                    new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username, Password);
                }
            });

            try {

                Message message = new MimeMessage(session);
                message.setFrom(new InternetAddress("universitysystem0@gmail.com"));
                message.setRecipients(Message.RecipientType.TO,
                InternetAddress.parse(email));
                message.setSubject("Account verification");
                String pswd = passwordGenerator();
                message.setText("Dear " + name + ", Your mail has been verified and your username is: " + user_name + " , your new password is : " + pswd + " ,You can use this username and password to login into our system.");

                Transport.send(message);
               // out.println("<h1>Mail has been successfully sent</h1>");
                String queryy = "INSERT INTO projectdb.users(username,password,name,phone,email,type) VALUES(?,?,?,?,?,?)";
                PreparedStatement preparedStmt = Con.prepareStatement(queryy);
                preparedStmt.setString(1, user_name);
                preparedStmt.setString(2, pswd);
                preparedStmt.setString(3, name);
                preparedStmt.setString(4, phoneNumber);
                preparedStmt.setString(5, email);
                preparedStmt.setString(6,"student");
                preparedStmt.execute();
               // response.sendRedirect("sign_in.jsp");
                response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('the email has been sent successfully');");
                pw.println("</script>");
                RequestDispatcher rd = request.getRequestDispatcher("sign_in.jsp");
                rd.include(request, response);

            } catch (MessagingException e) {
                throw new RuntimeException(e);
            }
            out.println("</body>");
            out.println("</html>");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Mail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}