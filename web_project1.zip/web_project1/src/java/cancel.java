/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;

/**
 *
 * @author Nourhan
 */
@WebServlet(urlPatterns = {"/cancel"})
public class cancel extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException, AddressException, MessagingException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            ResultSet rs = null;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            int id = Integer.parseInt(request.getParameter("id"));
            int sID = 0;
            String sname = "";
            String semail="";
            String username = request.getSession().getAttribute("username").toString();

            rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");
            int userID = 0;
            int row = 0;
            if (rs.next()) {

                userID = rs.getInt("userID");
            }
            rs = stmt.executeQuery("SELECT * FROM projectdb.appointments WHERE officehoursID = " + id + " AND userID='" + userID + "';");
            if (rs.next()) {

                rs = stmt.executeQuery("SELECT * FROM projectdb.officehours WHERE officehoursID = " + id + " AND status='Reserved';");

                if (rs.next()) {
                    sID = rs.getInt("userID");
                    sname = rs.getString("name");
                    rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE userID = " + sID + ";");
                    if (rs.next()) {
                        semail = rs.getString("email");
                    }

                    stmt.executeUpdate("UPDATE projectdb.officehours SET status='Available' WHERE officehoursID = " + id);
                    String queryy = "DELETE FROM projectdb.appointments WHERE officehoursID = " + id;
                    row = stmt.executeUpdate(queryy);
                    if (row != 0) {

                        rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");
                        String email = "";
                        String name = "";
                        while (rs.next()) {
                            email = rs.getString("email");
                            name = rs.getString("name");

                        }

                        final String username2 = "universitysystem0@gmail.com";
                        final String Password = "university_system";

                        Properties props = new Properties();
                        props.put("mail.smtp.starttls.enable", "true");
                        props.put("mail.smtp.auth", "true");
                        props.put("mail.smtp.host", "smtp.gmail.com");
                        props.put("mail.smtp.port", "587");

                        Session session = Session.getInstance(props,
                                new javax.mail.Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(username2, Password);
                            }
                        });
                        try {

                            Message message = new MimeMessage(session);
                            message.setFrom(new InternetAddress("universitysystem0@gmail.com"));
                            message.setRecipients(Message.RecipientType.TO,
                                    InternetAddress.parse(email));
                            message.setSubject("Cancelling Reservation of a slot");

                            message.setText("Dear " + name + " , Your reservation of office hour id " + id + " has been cancelled.");

                            Transport.send(message);

                            Message message2 = new MimeMessage(session);
                            message2.setFrom(new InternetAddress("universitysystem0@gmail.com"));
                            message2.setRecipients(Message.RecipientType.TO,
                                    InternetAddress.parse(semail));
                            message2.setSubject("Cancelling Reservation of a slot");

                            message2.setText("Dear " + sname + " , Your slot reservation of office hour id " + id + " has been cancelled by student " + name + " .");

                            Transport.send(message2);

                        } catch (MessagingException e) {
                            throw new RuntimeException(e);
                        }
                        response.setContentType("text/html");
                        PrintWriter pw = response.getWriter();
                        pw.println("<script type=\"text/javascript\">");
                        pw.println("alert('This office hour has been cancelled successfully');");
                        pw.println("</script>");
                        RequestDispatcher rd = request.getRequestDispatcher("profile.html");
                        rd.include(request, response);
                    }

                } else {

                    response.setContentType("text/html");
                    PrintWriter pw = response.getWriter();
                    pw.println("<script type=\"text/javascript\">");
                    pw.println("alert('slot isnt available');");
                    pw.println("</script>");
                    RequestDispatcher rd = request.getRequestDispatcher("cancel.jsp");
                    rd.include(request, response);

                }

            } else {

                response.setContentType("text/html");
                PrintWriter pw1 = response.getWriter();
                pw1.println("<script type=\"text/javascript\">");
                pw1.println("alert('You haven't reserve this slot to be able to cancel it');");
                pw1.println("</script>");
                RequestDispatcher rd = request.getRequestDispatcher("cancel.jsp");
                rd.include(request, response);
            }
        }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(cancel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
