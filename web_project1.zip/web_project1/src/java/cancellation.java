/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nourhan
 */
@WebServlet(urlPatterns = {"/cancellation"})
public class cancellation extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            ResultSet rs = null;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            int id = Integer.parseInt(request.getParameter("id"));
            String date = request.getParameter("date");
            String username = request.getSession().getAttribute("username").toString();
            int userid = 0;
            String email="";
            String semail="";
            String sname="";
            String name="";
            int studentID=0;
            rs=stmt.executeQuery("SELECT * FROM appointments WHERE officehoursID="+id);
            if(rs.next())
            {
            studentID=rs.getInt("userID");
            
            }
              rs=stmt.executeQuery("SELECT * FROM users WHERE userID="+studentID);
                if(rs.next())
                {
                  semail=rs.getString("email");//email of student
                  sname=rs.getString("name");
                
                }
            rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");
            int rows = 0;
            if (rs.next()) {

                userid = rs.getInt("userID");//staff member
                email=rs.getString("email");//staff member's email
                name=rs.getString("name");
                
              
                rows = stmt.executeUpdate("UPDATE projectdb.officehours SET status='Cancelled' WHERE officehoursID=" + id + " AND day='" + date + "' AND userID=" + userid + ";");
                if (rows != 0) {
                    int row2 = 0;
                    row2 = stmt.executeUpdate("DELETE FROM projectdb.appointments WHERE officehoursID=" + id + ";");
                    if (row2 != 0) {
                        
                         final String username2 = "universitysystem0@gmail.com";
                        final String Password = "university_system";

                        Properties props = new Properties();
                        props.put("mail.smtp.starttls.enable", "true");
                        props.put("mail.smtp.auth", "true");
                        props.put("mail.smtp.host", "smtp.gmail.com");
                        props.put("mail.smtp.port", "587");

                        Session session = Session.getInstance(props,
                                new javax.mail.Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(username2, Password);
                            }
                        });
                        try {

                            Message message = new MimeMessage(session);
                            message.setFrom(new InternetAddress("universitysystem0@gmail.com"));
                            message.setRecipients(Message.RecipientType.TO,
                                    InternetAddress.parse(email));
                            message.setSubject("Cancelling Reservation of a slot");

                            message.setText("Dear " + name + " , Your slot of office hour id " + id + " has been cancelled.");

                            Transport.send(message);

                            Message message2 = new MimeMessage(session);
                            message2.setFrom(new InternetAddress("universitysystem0@gmail.com"));
                            message2.setRecipients(Message.RecipientType.TO,
                                    InternetAddress.parse(semail));
                            message2.setSubject("Cancelling Reservation of a slot");

                            message2.setText("Dear " + sname + " , Your slot reservation of office hour id " + id + " has been cancelled by the staffmember " + name + " .");

                            Transport.send(message2);

                        } catch (MessagingException e) {
                            throw new RuntimeException(e);
                        }
                        response.setContentType("text/html");
                        PrintWriter pw = response.getWriter();
                        pw.println("<script type=\"text/javascript\">");
                        pw.println("alert('This office hour id has been cancelled successfully');");
                        pw.println("</script>");
                        RequestDispatcher rd = request.getRequestDispatcher("staffprofile.html");
                        rd.include(request, response);

                    }

                } else {
                    response.setContentType("text/html");
                    PrintWriter pw = response.getWriter();
                    pw.println("<script type=\"text/javascript\">");
                    pw.println("alert('This office hour id cant be cancelled');");
                    pw.println("</script>");
                    RequestDispatcher rd = request.getRequestDispatcher("cancellation.jsp");
                    rd.include(request, response);

                }

            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
