/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nourhan
 */
@WebServlet(urlPatterns = {"/cancellationAll"})
public class cancellationAll extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
         try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            Statement stmt1 = null;
            ResultSet rs = null;
            ResultSet rs1 = null;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            stmt1 = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            String date = request.getParameter("datee");
            String username = request.getSession().getAttribute("username").toString();
            int userid = 0;
            int officeid=0;
            rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");
            int rows =0;
           boolean flag=false;
            ArrayList<Integer> office=new ArrayList<Integer>();
            while (rs.next()) {
            
                userid = rs.getInt("userID");
                
                rows = stmt.executeUpdate("UPDATE projectdb.officehours SET status='Cancelled' WHERE  day='"+date+"' AND userID="+userid +";");
            
                
                rs1 = stmt.executeQuery("SELECT * FROM projectdb.officehours WHERE day= '" + date + "' AND userID="+userid +";");
  
                while(rs1.next())
                {   officeid=rs1.getInt("officehoursID"); 
                    int row2=stmt1.executeUpdate("DELETE FROM projectdb.appointments WHERE officehoursID="+officeid+";");
                    flag=true;
 
                
                    
                }
                if(flag==false)
                {
                response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('This office hour id cant be cancelled');");
                pw.println("</script>");
                 RequestDispatcher rd = request.getRequestDispatcher("cancellation.jsp");
                 rd.include(request, response);
                }
                else
                {
                    response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('This office hour id has been cancelled successfully');");
                pw.println("</script>");
                 RequestDispatcher rd = request.getRequestDispatcher("staffprofile.html");
                 rd.include(request, response);
                }
               
         }
               
                
            
          

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(cancellation.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}