
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nourhan
 */
@WebServlet(urlPatterns = {"/message"})
public class message extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            ResultSet rs = null;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            String subject = request.getParameter("subject");
            String content = request.getParameter("content");
            int toID=Integer.parseInt(request.getParameter("memberid"));
            String username = request.getSession().getAttribute("username").toString();
            String type="";
            String email="";
            String name="";
            String studentName="";
            rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");

            int id = 0;
            while (rs.next()) {
                studentName=rs.getString("name");
                id = rs.getInt("userID");
                type=rs.getString("type");

            }
               rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE  userID=" +toID +";");

            if (rs.next()) {
                
                String queryy = "INSERT INTO messages (`subject`, `body`,`from`, `to`) VALUES(?,?,?,?)";
                PreparedStatement preparedStmt = Con.prepareStatement(queryy);
                preparedStmt.setString(1, subject);
                preparedStmt.setString(2, content);
                preparedStmt.setInt(3, id);
                preparedStmt.setInt(4,toID);
                preparedStmt.execute();
                rs=stmt.executeQuery("SELECT * FROM users WHERE userID="+toID);
                if(rs.next())
                {
                  email=rs.getString("email");
                  name=rs.getString("name");
                  final String username2 = "universitysystem0@gmail.com";
                        final String Password = "university_system";

                        Properties props = new Properties();
                        props.put("mail.smtp.starttls.enable", "true");
                        props.put("mail.smtp.auth", "true");
                        props.put("mail.smtp.host", "smtp.gmail.com");
                        props.put("mail.smtp.port", "587");

                        Session session1 = Session.getInstance(props,
                                new javax.mail.Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(username2, Password);
                            }
                        });
                        try {

                            Message message = new MimeMessage(session1);
                            message.setFrom(new InternetAddress("universitysystem0@gmail.com"));
                            message.setRecipients(Message.RecipientType.TO,
                                    InternetAddress.parse(email));
                            message.setSubject("Message from a student");

                            message.setText("Dear " + name+ " , You have recieved a message from "+studentName+" and its content is ' " +content+" ' .");

                            Transport.send(message);

                            

                        } catch (MessagingException e) {
                            throw new RuntimeException(e);
                        }
                
                }
                
                
                response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('This message has been sent successfully');");
                pw.println("</script>");
                if(type.equalsIgnoreCase("student"))
                {
                 RequestDispatcher rd = request.getRequestDispatcher("profile.html");
                 rd.include(request, response);
                }
                else
                {
                RequestDispatcher rd = request.getRequestDispatcher("staffprofile.html");
                        rd.include(request, response);
                }
                        
            } else {
                response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('invalid name or subject');");
                pw.println("</script>");
                if(type.equalsIgnoreCase("student"))
                {
                 RequestDispatcher rd = request.getRequestDispatcher("profile.html");
                 rd.include(request, response);
                }
                else
                {
                RequestDispatcher rd = request.getRequestDispatcher("staffprofile.html");
                        rd.include(request, response);
                }
            }

           
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
