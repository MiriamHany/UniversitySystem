import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nourhan
 */
@WebServlet(urlPatterns = {"/messageALL"})
public class messageALL extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException, MessagingException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            ResultSet rs = null;
            //ResultSet rs1 = null;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            String subject = request.getParameter("subject");
            String content = request.getParameter("content");
            String username = request.getSession().getAttribute("username").toString();
            String email = "";
            String staffname = "";
            boolean flag = true;
            String StudentName="";
              rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");

            int id = 0;
            if (rs.next()) {

                id = rs.getInt("userID");
                StudentName=rs.getString("name");
            }
          rs = stmt.executeQuery("SELECT * FROM projectdb.staffmember WHERE role='TA' AND subject='" + subject + "';");

            while (rs.next()) {
                int TAID = rs.getInt("userID");
                flag = false;
                String queryy = "INSERT INTO messages (`subject`, `body`,`from`, `to`) VALUES(?,?,?,?)";
                PreparedStatement preparedStmt = Con.prepareStatement(queryy);
                preparedStmt.setString(1, subject);
                preparedStmt.setString(2, content);
                preparedStmt.setInt(3, id);
                preparedStmt.setInt(4, TAID);
                preparedStmt.execute();

                
            }
            final String username2 = "universitysystem0@gmail.com";
            final String Password = "university_system";

            Properties props = new Properties();
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.host", "smtp.gmail.com");
            props.put("mail.smtp.port", "587");

            Session session1 = Session.getInstance(props,
                    new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(username2, Password);
                }
            });
            Message message = new MimeMessage(session1);
            message.setFrom(new InternetAddress("universitysystem0@gmail.com"));
            rs = stmt.executeQuery("SELECT * FROM projectdb.staffmember WHERE role='TA' AND subject='" + subject + "';");
            int TAID = 0;
            ArrayList<String> emails = new ArrayList<String>();
            ArrayList<String> names = new ArrayList<String>();
            while (rs.next()) {

                TAID = rs.getInt("userID");
                Statement stmt1 = null;
                ResultSet rs1 = null;
                stmt1 = Con.createStatement();
                rs1 = stmt1.executeQuery("SELECT * FROM users WHERE userID=" + TAID);
                if (rs1.next()) {
                    email = rs1.getString("email");//staff members' email
                    staffname = rs1.getString("name");//staff members' name
                    emails.add(email);
                    names.add(staffname);

                }
            }
            for (int i = 0; i < emails.size(); i++) {
                message.setRecipients(Message.RecipientType.TO,
                        InternetAddress.parse(emails.get(i)));
                message.setSubject("Message from a student");

                message.setText("Dear  " + names.get(i)+ ",You have recieved a message from student  "+StudentName+" And its content is "+content+".");

                Transport.send(message);
            }

              

                if (!flag) {
                    response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('Messages are sent successfully');");
                pw.println("</script>");
                RequestDispatcher rd = request.getRequestDispatcher("profile.html");
                rd.include(request, response);

                }
                else{
                 response.setContentType("text/html");
                 PrintWriter pw = response.getWriter();
                    pw = response.getWriter();
                    pw.println("<script type=\"text/javascript\">");
                    pw.println("alert('There is no staff members for this subject');");
                    pw.println("</script>");
                    RequestDispatcher rd = request.getRequestDispatcher("messageALL.jsp");
                    rd.include(request, response);
                }

             
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(messageALL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}