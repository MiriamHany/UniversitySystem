/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nourhan
 */
@WebServlet(urlPatterns = {"/messagesubject"})
public class messagesubject extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(message.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            ResultSet rs = null;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            String username = request.getSession().getAttribute("username").toString();
            String content = request.getParameter("content");
            String subject = "";
            rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");
            int id = 0;
            boolean flag = true;
            if (rs.next()) {

                id = rs.getInt("userID");
            }
            rs = stmt.executeQuery("SELECT * FROM projectdb.staffmember WHERE userID= " + id + ";");
            if (rs.next()) {
                subject = rs.getString("subject");

            }

            rs = stmt.executeQuery("SELECT * FROM projectdb.staffmember WHERE subject= '" + subject + "';");
            while (rs.next()) {
                
                int to = rs.getInt("userID");
                if (to != id) {
                    flag = false;
                    String queryy = "INSERT INTO messages (`subject`, `body`,`from`, `to`) VALUES(?,?,?,?)";
                    PreparedStatement preparedStmt = Con.prepareStatement(queryy);
                    preparedStmt.setString(1, subject);
                    preparedStmt.setString(2, content);
                    preparedStmt.setInt(3, id);
                    preparedStmt.setInt(4, to);
                    preparedStmt.execute();
                    response.setContentType("text/html");
                    PrintWriter pw = response.getWriter();
                    pw.println("<script type=\"text/javascript\">");
                    pw.println("alert('Messages are sent successfully');");
                    pw.println("</script>");
                    RequestDispatcher rd = request.getRequestDispatcher("staffprofile.html");
                    rd.include(request, response);

                }

            }
            if (flag) {
                response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('There is no staff members for this subject');");
                pw.println("</script>");
                RequestDispatcher rd = request.getRequestDispatcher("messagesubject.jsp");
                rd.include(request, response);

            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(messagesubject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(messagesubject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(messagesubject.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(messagesubject.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
