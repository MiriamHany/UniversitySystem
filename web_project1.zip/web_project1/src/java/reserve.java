/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Nourhan
 */
@WebServlet(urlPatterns = {"/reserve"})
public class reserve extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException, AddressException, MessagingException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                Class.forName("com.mysql.jdbc.Driver").newInstance();
            } catch (InstantiationException ex) {
                Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IllegalAccessException ex) {
                Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
            }
            String URL = "jdbc:mysql://localhost:3306/projectdb";
            String userName = "root";
            String password = "root";
            Connection Con = null;
            Statement stmt = null;
            ResultSet rs = null;
            String email="";
            String name="";
            int userID=0;
            int from=0;
            int to=0;
            int staffid=0;
            Con = DriverManager.getConnection(URL, userName, password);
            stmt = Con.createStatement();
            DatabaseMetaData DBMetaData = Con.getMetaData();
            String EngineName = DBMetaData.getDatabaseProductName();
            String EngineVer = DBMetaData.getDatabaseProductVersion();
            int id = Integer.parseInt(request.getParameter("id"));
            String username = request.getSession().getAttribute("username").toString();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet reserve</title>");
            out.println("</head>");
            out.println("<body>");
  
            rs = stmt.executeQuery("SELECT * FROM projectdb.users WHERE username= '" + username + "';");
            int idd = 0;

            if (rs.next()) {

                idd = rs.getInt("userID");
                name=rs.getString("name");
                
            }

            rs = stmt.executeQuery("SELECT * FROM projectdb.officehours WHERE officehoursID = " + id + " AND status='Available';");

            if (rs.next()) {
                staffid=rs.getInt("userID");
                from=rs.getInt("From");
                to=rs.getInt("To");
                String staffname=rs.getString("name");
                stmt.executeUpdate("UPDATE projectdb.officehours SET status='Reserved' WHERE officehoursID = " + id);
                String queryy = "INSERT INTO projectdb.appointments(officehoursID,userID) VALUES(?,?)";
                PreparedStatement preparedStmt = Con.prepareStatement(queryy);
                preparedStmt.setInt(1, id);
                preparedStmt.setInt(2, idd);
                preparedStmt.execute();
                
                rs=stmt.executeQuery("SELECT * FROM appointments WHERE officehoursID="+id);
                if(rs.next())
                {
                   userID=rs.getInt("userID");
                   rs=stmt.executeQuery("SELECT * FROM users WHERE userID="+staffid);
                   if(rs.next())
                   {
                    email=rs.getString("email");
                      final String username2 = "universitysystem0@gmail.com";
                        final String Password = "university_system";

                        Properties props = new Properties();
                        props.put("mail.smtp.starttls.enable", "true");
                        props.put("mail.smtp.auth", "true");
                        props.put("mail.smtp.host", "smtp.gmail.com");
                        props.put("mail.smtp.port", "587");

                        Session session1 = Session.getInstance(props,
                                new javax.mail.Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(username2, Password);
                            }
                        });
                        try {

                            Message message = new MimeMessage(session1);
                            message.setFrom(new InternetAddress("universitysystem0@gmail.com"));
                            message.setRecipients(Message.RecipientType.TO,
                                    InternetAddress.parse(email));
                            message.setSubject("Reservation of a slot");

                            message.setText("Dear " + staffname+ " , Your slot of office hour id "+ id+" from "+from+" to "+to+"  is reserved by "+name+".");

                            Transport.send(message);

                            

                        } catch (MessagingException e) {
                            throw new RuntimeException(e);
                        }
                   }
                response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('This office hour has been reserved successfully');");
                pw.println("</script>");
                RequestDispatcher rd = request.getRequestDispatcher("profile.html");
                rd.include(request, response);
                }
                

            } else {

                response.setContentType("text/html");
                PrintWriter pw = response.getWriter();
                pw.println("<script type=\"text/javascript\">");
                pw.println("alert('slot isnt available');");
                pw.println("</script>");
                RequestDispatcher rd = request.getRequestDispatcher("reserve.jsp");
                rd.include(request, response);

            }

            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(reserve.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
